﻿using Microsoft.AspNetCore.Mvc;
namespace Prova2Bim.API.Controllers
{

    public class EntrevistadoController:ControllerBase
    {
        [ApiController]
        [Route("api/[controller]")]
       
        {
            private readonly IEntrevistadoService _service;

            public EntrevistadoController(IEntrevistadoService service)
            {
                _service = service;
            }

            [HttpPost]
            public IActionResult Post(EntrevistadoController c)
            {
                try
                {
                    _service.Create(c);
                    return Ok("Entrevista enviada com sucesso!");
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }

            [HttpGet]
            public IActionResult Get()
            {
                return Ok(_service.GetAll());
            }
        }
    }
