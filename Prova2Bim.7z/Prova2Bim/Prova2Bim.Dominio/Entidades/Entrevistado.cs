﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prova2Bim.Dominio.Entidades
{
    public class Entrevistado
    {
            public string NomeEntrevistado { get; set; }
            public string Idade { get; set; }
            public string CPF { get; set; }
            public bool EstaEmpregado { get; set; }
            public string DescricaoEmprego { get; set; }
            public bool MoraAluguel { get; set; }
            public string ValorAluguel { get; set; }
            public int Contato { get; set; }
        }
    }


