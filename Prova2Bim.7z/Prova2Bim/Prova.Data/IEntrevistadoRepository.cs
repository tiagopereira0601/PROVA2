﻿namespace Prova2Bim.Dominio.Entidades;
public class Entrevistado
{

}
public interface IEntrevistadoRepository
{
    List<Entrevistado> GetAll();

    public class EntrevistadoRepository : IEntrevistadoRepository
    {
        private static List<Entrevistado> _lista = new List<Entrevistado>();

        public void Add(Entrevistado entrevistado)
        {
            _lista.Add(entrevistado);
        }

        public List<Entrevistado> GetAll()
        {
            return _lista;
        }
    }
    public interface IEntrevistadoRepository
    {
    }
}
